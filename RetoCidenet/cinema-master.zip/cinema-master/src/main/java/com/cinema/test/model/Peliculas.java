package com.cinema.test.model;

public class Peliculas {

}
